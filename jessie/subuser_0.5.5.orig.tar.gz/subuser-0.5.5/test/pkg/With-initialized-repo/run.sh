#!/bin/bash
/pwd/test/prepare-test-repos.sh
/pwd/logic/subuser pkg init
/pwd/logic/subuser $@
