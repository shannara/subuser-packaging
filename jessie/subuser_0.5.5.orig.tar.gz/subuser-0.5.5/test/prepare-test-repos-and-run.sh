#!/bin/bash
/pwd/test/prepare-test-repos.sh
#run
/pwd/logic/subuser $@
