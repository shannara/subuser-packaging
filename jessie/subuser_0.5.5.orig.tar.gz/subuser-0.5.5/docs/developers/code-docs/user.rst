The User object
---------------

.. automodule:: subuserlib.classes.user
 :members:
 :undoc-members:

.. toctree::

  registry
  installed-images
  config
  docker

