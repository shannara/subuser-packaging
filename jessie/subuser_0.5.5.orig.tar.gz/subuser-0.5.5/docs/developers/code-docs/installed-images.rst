Installed images
----------------

.. automodule:: subuserlib.classes.installedImages
 :members:
 :undoc-members:

.. automodule:: subuserlib.classes.installedImage
 :members:
 :undoc-members:

