Screenshots
-----------

Programs don't look any different when running under subuser. So there's not much to see.

.. image:: ./screenshots/liferea+firefox.png

However, notice that my ``firefox`` subuser has different settings and different plugins installed than my ``google-calendar`` subuser.

.. image:: ./screenshots/emacs+texttest.png

Subuser itself is developed in emacs running in subuser. The test suit also runs within subuser.

.. image:: ./screenshots/libreoffice.png

Libreoffice also works in subuser as do most programs. Note the emptiness of the home-dir.
