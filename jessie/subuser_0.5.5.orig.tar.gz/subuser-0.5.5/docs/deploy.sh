#/bin/sh
rsync -ru ./_build/html/ might@37.205.9.176:/home/might/web/subuser.org/
